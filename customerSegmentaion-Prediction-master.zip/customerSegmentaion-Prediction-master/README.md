# customerSegmentaion-Prediction

Folder name : Capture_Logs contains get_Logger.py with class Logger_Class.
It's a common class used for logging and configration can be set in logging.conf.
Refer Example in test.py to implement common logging  


Training Flow:

main.py >> Capture_Logs.get_Logger >> trainingModel.py >> Data_Ingestion.fetch_mongodata >> Data_preprocessing.preprocessing.is_null_present >>  Data_preprocessing.preprocessing.check_Outliers  >> Clustering_model.clustering.KMeansClustering >>  Data_preprocessing.preprocessing.train_validate_test_split >> Classification_model.tuner


reTraining Flow:

main.py(uncomment line 11 and 12 to execute retraining model) >> Capture_Logs.get_Logger >> Data_Ingestion.fetch_mongodata >> Data_Validator.schema_validator.Schema_Structure >> insert record into mongoDB >> trainingModel.py >> Data_Ingestion.fetch_mongodata >> Data_preprocessing.preprocessing.is_null_present >>  Data_preprocessing.preprocessing.check_Outliers  >> Clustering_model.clustering.KMeansClustering >>  Data_preprocessing.preprocessing.train_validate_test_split >> Classification_model.tuner


Fastapi:

run_fastApi.bat >> internally it calls app_fastApi.py 

StreamLit:

run_streamlit.bat >> internally it calls run_streamlit.py


ML Flow doc: https://medium.com/@jasonpben/heart-disease-classifier-tuning-using-optuna-and-mlflow-fc1366eefdec

