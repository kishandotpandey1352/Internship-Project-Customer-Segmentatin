import pandas as pd
import numpy as np
from pickle import dump
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import normalize

class Preprocessor:
    """
        This class shall  be used to clean and transform the data before training.

        Written By: Suyog
        Version: 1.0
        Revisions: None

    """
    def __init__(self, logger_object):
        self.logger = logger_object
    
    def fillna(self,data,columns,value):
        """
                Method Name: fillna
                Description: This method filling na values to the given columns from a pandas dataframe.
                Output: A pandas DataFrame after filling na values the specified columns.
                On Failure: Raise Exception


                Version: 1.0
                Revisions: None

        """
        self.logger.info('Entering Preprocessor >> fillna')
        self.data=data
        self.columns=columns
        self.value = value
        try:

            self.fillna_data=self.data[self.columns].fillna(self.value) # drop the labels specified in the columns
            self.logger.info('Fillna Successful')
            self.logger.info('Exiting Preprocessor >> fillna')
            return self.fillna_data
        except Exception as e:
            self.logger.info('Exception occured in fillna method of the Preprocessor class. Exception message:  '+str(e.args))
            self.logger.info('Fillna Unsuccessful. Exited the Fillna method of the Preprocessor class')
            raise Exception()


    def is_null_present(self,data):
        """
            Method Name: is_null_present
            Description: This method checks whether there are null values present in the pandas Dataframe or not.
            Output: Returns a Boolean Value. True if null values are present in the DataFrame, False if they are not present.
            On Failure: Raise Exception

            Version: 1.0
            Revisions: None

        """
        self.logger.info('Entering Preprocessor >> is_null_present')
        self.null_present = False
        try:
            self.null_counts=(data.values=="Null").sum() # check for the count of "Null" values in whole dataframe
            for i in range(0, self.null_counts):
                if i>0:
                    self.null_present=True
                    break
            if(self.null_present): # write the logs to see which columns have null values
                dataframe_with_null = pd.DataFrame()
                dataframe_with_null['columns'] = data.columns
                dataframe_with_null['missing values count'] = np.asarray((data.values=="Null").sum())
                dataframe_with_null.to_csv('Data_files/EDA/features_null_value_count.csv') # storing the null column information to file
                self.logger.info('Finding missing values is a success')
                self.logger.info('Exiting Preprocessor >> is_null_present')
            return self.null_present
        except Exception as e:
            self.logger.info('Exception occured in is_null_present method of the Preprocessor class. Exception message:  ' + str(e.args))
            self.logger.info('Finding missing values failed. Exited the is_null_present method of the Preprocessor class')
            raise Exception()

    def correlation(self,dataset, threshold):
        """
                    Method Name: correlation
                    Description: This method find's the correlation between various data columns and
                    with threshold result return new column list.
                    Output: A columns list post finding correlation based on threshold.
                    On Failure: Raise Exception


                    Version: 1.0
                    Revisions: None

            """
        self.logger.info('Entering Preprocessor >> correlation')
        try:
            col_corr = set()  # Set of all the names of correlated columns
            corr_matrix = dataset.corr()
            for i in range(len(corr_matrix.columns)):
                for j in range(i):
                    if abs(corr_matrix.iloc[i, j]) > threshold:  # we are interested in absolute coeff value
                        colname = corr_matrix.columns[i]  # getting the name of column
                        col_corr.add(colname)
            self.logger.info('Exiting Preprocessor >> correlation')
            return col_corr
        except Exception as e:
                self.logger.info('Exception occured in correlation method of the Preprocessor class. Exception message:  ' + str(e.args))
                self.logger.info('correlation Unsuccessful. Exited the correlation method of the Preprocessor class')
                raise Exception()

    def check_Outliers(self, data, column_name):
        """
            Method Name: correlation
            Description: This method check for outliers in given column.
            Output: A new data frame with outliers removed.
            On Failure: Raise Exception

            Version: 1.0
            Revisions: None

        """
        self.logger.info('Entering Preprocessor >> check_Outliers')
        try:
            #self.data[column_name] = self.data[column_name].astype(str).astype(float)
            #IQR=self.data[column_name].quantile(0.75)-self.data[column_name].quantile(0.25)
            data[column_name] = data[column_name].astype(str).astype(float)
            IQR = data[column_name].quantile(0.75) - data[column_name].quantile(0.25)
            lower_bridge = data[column_name].quantile(0.25) - (IQR * 1.5)
            upper_bridge = data[column_name].quantile(0.75) + (IQR * 1.5)
            data.loc[data[column_name] >= upper_bridge, column_name] = upper_bridge
            self.logger.info('Exiting Preprocessor >> check_Outliers')
            return data
        except Exception as e:
                self.logger.info('Exception occured in check_Outliers method of the Preprocessor class. Exception message:  ' + str(e.args))
                self.logger.info('check_Outliers Unsuccessful. Exited the check_Outliers method of the Preprocessor class')
                raise Exception()

    
    def train_validate_test_split(self, df, train_percent=.9, seed=42):
        """
            Method Name: train_validate_test_split
            Description: This method splits data into train_validate_test.
            Output: A new data frame with split size.
            On Failure: Raise Exception

            Version: 1.0
            Revisions: None

        """
        self.logger.info('Entering Preprocessor >> train_validate_test_split')
        try:
           np.random.seed(seed)
           #perm = np.random.permutation(df.index)
           m = len(df.index)
           train_end = int(train_percent * m)
        #    validate_end = int(validate_percent * m) + train_end
           train = df.iloc[:train_end]
           validate = df.iloc[train_end:]
        #    test = df.iloc[[validate_end:]]
           return train, validate
        except Exception as e:
            self.logger.info(
                'Exception occured in train_validate_test_split method of the Preprocessor class. Exception message:  ' + str(e.args))
            self.logger.info(
                'check_Outliers Unsuccessful. Exited the train_validate_test_split method of the Preprocessor class')
            raise Exception()
