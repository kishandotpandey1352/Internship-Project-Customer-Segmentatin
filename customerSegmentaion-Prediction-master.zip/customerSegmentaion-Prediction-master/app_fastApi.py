# # -*- coding: utf-8 -*-
# """
# Created on Sat Oct 22 02:20:31 2020

# @author: Neha Kushwaha
# """

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
import warnings
import pickle
import pandas as pd
from Capture_logs import get_logger
from pydantic import BaseModel

sav_file = "Model/customer_classifier_model.sav"
with warnings.catch_warnings():
      warnings.simplefilter("ignore", category=UserWarning)
      classifier = pickle.load(open(sav_file, 'rb'))
      # load the scaler
      scaler_std = pickle.load(open('Model/customer_classifier_scalar.sav', 'rb'))
app = FastAPI()
templates = Jinja2Templates(directory="Templates")

def customer_classification(Balance_html,Age_html,Gender_html,logger):
  logger.info("Entering app >> customer_classification method")
  try:
    logger.info("customer_classification")
    logger.info(Balance_html)
    logger.info(Age_html)
    logger.info(Gender_html)
    if Gender_html == 'Male' :
        Gender_temp = 1
    if Gender_html == 'Female' :
        Gender_temp = 1
    if Balance_html:
        Balance = Balance_html
    if Age_html:
        Age = Age_html
    array_std = list()
    array_std.append(Balance)
    array_std.append(Age)
    array_std.append(Gender_temp)
    logger.info(array_std)
    df = pd.DataFrame([array_std])
    df.columns =['balance', 'age', 'gender_M']
    logger.info(df)
    array_std_scl = scaler_std(df)
    logger.info(array_std_scl)
    prediction=classifier.predict(array_std_scl)
    logger.info(prediction)
    return prediction
  except Exception:
    # logging the unsuccessful Training
    logger.info('Unsuccessful End app >> customer_classification method')
    logger.error("Exception occurred in app >> customer_classification", exc_info=True)
    raise Exception

class ClassifierRequest(BaseModel): 
    Gender : str
    Age : int
    Balance : float

@app.get("/")
def home_get(request : Request):
    '''
    displays the Bank customer classifier/dashboard home page
    '''
    logger_class = get_logger.LoggerClass()
    logger = logger_class.get_logger('Logs/fastapi.log')
    logger.info("home_get")
    query_params = str(request.query_params)
    # logger.info(query_params)
    # logger.info(query_params.split('&')[0][8:])
    # logger.info(query_params.split('&')[1][5:])
    # logger.info(query_params.split('&')[2][9:])
    if(len(query_params)>0):
        Gender_r =  query_params.split('&')[0][8:]
        Age_r =  query_params.split('&')[1][5:]
        Balance_r =  query_params.split('&')[2][9:]
        if len(Gender_r)>0 and len(Age_r)>0 and len(Balance_r)>0:
            result=customer_classification(float(Balance_r),int(Age_r),Gender_r,logger)
            if str(result) == '[0]':
                result = "Class 0"
            if str(result) == '[1]':
                result = "Class 1"
            if str(result) == '[2]':
                result = "Class 2"
        else:
            result = "Enter valid inputs"
    else:
        result = "Enter valid inputs"
    return templates.TemplateResponse("home.html",{
        "request": request,
        "prediction_text" : str(result)
    })


@app.get("/Classifiy")
def home_classifiy(request : Request, Gender_ : str, Age_ : str, Balance_ : str):
    '''
    displays the Bank customer classifier/dashboard home page
    '''
    logger_class = get_logger.LoggerClass()
    logger = logger_class.get_logger('Logs/app_fastapi.log')
    logger.info("home")
    logger.info(Gender_)
    logger.info(Age_)
    logger.info(Balance_)
    if Gender_ and Age_ and Balance_:
        result=customer_classification(float(Balance_),int(Age_),Gender_,logger)
        if str(result) == '[0]':
            result = "Class 0"
        if str(result) == '[1]':
            result = "Class 1"
        if str(result) == '[2]':
            result = "Class 2"
    else:
        result = "Enter valid inputs"
    return templates.TemplateResponse("home.html",{
        "request": request,
        "prediction_text" : str(result)
    })

@app.post("/Classify")
def clasify(classify_request:ClassifierRequest):
    # logger_class = get_Logger.LoggerClass()
    # logger = logger_class.get_logger('Logs/app_fastapi.log')
    '''
    Classifiy the Bank customer and return the type of customer
    '''
    logger_class = get_logger.LoggerClass()
    logger = logger_class.get_logger('Logs/app_fastapi.log')
    logger.info("clasify")
    logger.info(classify_request.Gender)
    logger.info(classify_request.Age)
    logger.info(classify_request.Balance)
    result=customer_classification(classify_request.Balance,classify_request.Age,classify_request.Gender,logger)
    return {"msg": "customer Classifiy successfully!",
    "result": str(result)}
    


