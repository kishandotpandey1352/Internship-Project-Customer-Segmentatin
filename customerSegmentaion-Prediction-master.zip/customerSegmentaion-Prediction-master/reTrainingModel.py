from pymongo import MongoClient
import pandas as pd
import json
from Data_validator import schema_validator

class RetrainModel:
    """
    This class shall be used for Retraining the data and creating new classification pickeled version file.

    Written By: Neha_Kushwaha
    Version: 1.0
    Revisions: None

    """
    def __init__(self, logger_object):
        self.logger = logger_object
        self.uri="mongodb+srv://Bank_Customer_Ineuron:qwertyuiop1@cluster0.byqvv.mongodb.net/Bank_Customer_Ineuron?retryWrites=true&w=majority"
        self.database_name = 'Bank_Customer_Test'

    def ReTrain(self):
        """
        Method Name: ReTrain
        Description: This method ReTrain the model.
        Output: updated version pickel file.
        On Failure: Raise Exception

        Written By: Neha_Kushwaha
        Version: 1.0
        Revisions: None

        """
        try:
            self.logger.info('Entering Retrain_Model >> ReTrain')
            client = MongoClient(self.uri) #connect to the client
            db = client.get_database(self.database_name) #Get Database details
            #select the collection within the database
            mongodDbCollection = db.Customer_Details_Test
            #Get last Id from
            count = mongodDbCollection.count_documents({})

            #Get the new record in json format and latest id with count + 1
            f = open( "Data_Validator/dummy_Record.json" , "rb" )
            jsonObject = json.load(f)
            f.close()

            for item in jsonObject:
                count = count + 1
                # entry = {'id_': str(count)}
                item['_id'] = str(count)
            
            with open('Data_Validator/dummy_record_id.json', 'w') as json_file:
                json.dump(jsonObject, json_file)

            #Validate the record and Insert new json document to mongodb 
            schema_validator_obj = schema_validator.SchemaStructure(self.logger)
            f = open( "Data_Validator/dummy_record_id.json" , "rb" )
            jsonObject = json.load(f)
            f.close()

            for item in jsonObject:
                if(schema_validator_obj.validate_schema(item)):
                    mongodDbCollection.insert_one(item)

            self.logger.info('Record Added successfully for id number :'+ str(count))
            self.logger.info('Exiting Retrain_Model >> ReTrain')
        except Exception as e:
            self.logger.error('Exception occured in ReTrain method of the Retrain_Model class Exception message: '+str(e))
            self.logger.info('Data Load Unsuccessful. Exited the ReTrain method of the Retrain_Model class')
            raise Exception()