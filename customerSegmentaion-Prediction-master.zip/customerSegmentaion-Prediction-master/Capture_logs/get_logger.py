import logging.config

class LoggerClass:
    def __init__(self):
        self.config_file = ('Capture_Logs/logging.conf')

    def get_logger(self, logfilename):
        logging.config.fileConfig(self.config_file, defaults={'logfilename': logfilename}, disable_existing_loggers=False)
        self.logger = logging.getLogger("bankCustomerLog")
        return self.logger