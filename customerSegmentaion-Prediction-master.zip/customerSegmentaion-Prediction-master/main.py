from trainingModel import trainModel
from Capture_logs import get_logger
from reTrainingModel import RetrainModel

if __name__ == "__main__":
    logger_class = get_logger.LoggerClass()
    logger = logger_class.get_logger('Logs/main.log')
    
    logger.info("Entering main method")
    #to call Retrain class un-comment below two lines of code
    #R = Retrain_Model(logger)
    #R.ReTrain()

    #Calling trainingModel.py
    T = trainModel()
    T.trainingModel()
    logger.info("Exiting main method")
