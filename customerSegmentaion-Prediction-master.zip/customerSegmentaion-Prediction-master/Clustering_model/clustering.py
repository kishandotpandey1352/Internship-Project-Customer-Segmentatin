import pickle
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from kneed import KneeLocator
import pandas as pd
import matplotlib.cm as cm
import numpy as np
import plotly.figure_factory as ff
from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import silhouette_samples, silhouette_score
import plotly

from sklearn import metrics


#for finding elbow point
#from file_operations import file_methods
class CreateClusters:
    """
            This class shall  be used to divide the data into clusters before training.

            Written By: kishan Pandey
            Version: 1.0
            Revisions: None

            """

    def __init__(self, logger_object):
        """ Docstring"""
        self.logger = logger_object


    def elbow_plot(self,data):
        """
                        Method Name: elbow_plot
                        Description: This method saves the plot to decide the optimum number of clusters to the file.
                        Output: A picture saved to the directory
                        On Failure: Raise Exception

                        Written By: Kishan Pandey
                        Version: 1.0
                        Revisions: None"""

        self.logger.info('Entering Elbow_Plot >> elbow_plot')
        wcss=[] # initializing an empty list
        score_dic={}
        X = data[['balance', 'age', 'gender_M']]

        try:
            for i in range(1,11):
                kmeans = KMeans(n_clusters=i,init = 'k-means++', random_state = 42)
                model=kmeans.fit(X)
                #fitting the data to the KMeans Algorithm
                wcss.append(kmeans.inertia_)
                score_dic[i]=wcss[i-1]
            plt.plot(range(1,11),wcss)# creating the graph between WCSS and the number of clusters
            plt.title('The Elbow Method')
            plt.xlabel('Number of clusters')
            plt.ylabel('WCSS')
            #plt.show()
            plt.savefig('Plots/Clustering/K-Means_Elbow.PNG')#saving the elbow plot locally
            # finding the value of the optimum cluster programmatically
            self.kneedle = KneeLocator(range(1, 11), wcss, curve='convex', direction='decreasing')
            self.logger.info('The WCSS value at each cluster is: {}'.format(score_dic))
            self.logger.info('Elbow Plot drawn and number of clusters found are: {}'.format(self.kneedle.knee))
            self.logger.info('Exiting elbow_plot >> elbow_plot')
            return self.kneedle.knee

        except Exception as e:
            self.logger.error('Exception occured in elbow_plot method of the CreateClusters class. Exception message: ' + str(e.args))
            self.logger.info('Plotting elbow plot and finding number of clusters  failed, Check elbow_plot method for more info')
            raise Exception()

    def silhouet_plot(self, data):
        """
                                Method Name: silhouet_plot
                                Description: This method saves the silhouet_plot to the file.
                                Output: A picture saved to the directory
                                On Failure: Raise Exception

                                Written By:Kishan Pandey
                                Version: 1.0
                                Revisions: None"""

        self.logger.info('Entering silhouet_plot >> silhouet_plot')
        range_n_clusters = [2, 3, 4, 5, 6]
        X = data[['balance', 'age', 'gender_M']]
        print(X)

        try:
            for n_clusters in range_n_clusters:
                fig, ax = plt.subplots(1, 1)
                fig.set_size_inches(18, 7)
                ax.set_xlim([-0.1, 1])
                ax.set_ylim([0, len(X) + (n_clusters + 1) * 10])

                clusterer = KMeans(n_clusters=n_clusters, init='k-means++', random_state=42)

                cluster_labels = clusterer.fit_predict(X)# fitting the data to the KMeans Algorithm
                #print(cluster_labels)


                silhouette_avg = silhouette_score(X, cluster_labels)
                #print("For n_clusters =", n_clusters, "The average silhouette_score is :", silhouette_avg)
                #print("good")

                # Compute the silhouette scores for each sample
                sample_silhouette_values = silhouette_samples(X, cluster_labels)

                y_lower = 10
                for i in range(n_clusters):
                    # Aggregate the silhouette scores for samples belonging to
                    # cluster i, and sort them
                    ith_cluster_silhouette_values = sample_silhouette_values[cluster_labels == i]

                    ith_cluster_silhouette_values.sort()

                    size_cluster_i = ith_cluster_silhouette_values.shape[0]
                    y_upper = y_lower + size_cluster_i

                    cmap = cm.get_cmap("Spectral")
                    color = cmap(float(i) / n_clusters)
                    ax.fill_betweenx(np.arange(y_lower, y_upper),
                                     0, ith_cluster_silhouette_values,
                                     facecolor=color, edgecolor=color, alpha=0.7)

                    # Label the silhouette plots with their cluster numbers at the middle
                    ax.text(-0.05, y_lower + 0.5 * size_cluster_i, str(i))

                    # Compute the new y_lower for next plot
                    y_lower = y_upper + 10  # 10 for the 0 samples

                ax.set_title("The silhouette plot for the various clusters.")
                ax.set_xlabel("The silhouette coefficient values")
                ax.set_ylabel("Cluster label")

                # The vertical line for average silhouette score of all the values
                ax.axvline(x=silhouette_avg, color="red", linestyle="--")

                ax.set_yticks([])  # Clear the yaxis labels / ticks
                ax.set_xticks([-0.1, 0, 0.2, 0.4, 0.6, 0.8, 1])

                plt.suptitle(("Silhouette analysis for KMeans clustering on sample data "
                              "with n_clusters = %d" % n_clusters),
                             fontsize=14, fontweight='bold')
                plt.savefig("Plots/Clustering/Silhouette_plot_for_cluster_{}".format(n_clusters))

            
            self.logger.info('Silhouette plots are saved.')
            self.logger.info('Exiting silhouet_plot >> silhouet_plot')
            
        except Exception as e:
            self.logger.error('Exception occured in silhouet_plot method of the CreateClusters class. Exception message: ' + str(e.args))
            self.logger.info('Plotting the silhouette plot. Exited the silhouet_plot method of the CreateClusters class')
            raise Exception()

    def agglomerative_cluster(self,data,n_cluster):
        """
                                        Method Name: create_clusters
                                        Description: Create a dendgram plot.
                                        Output: A plot with dendograms
                                        On Failure: Raise Exception

                                        Written By:Kishan
                                        Version: 1.0
                                        Revisions: None"""

        self.logger.info('Entering agglomerative_cluster method >> agglomerative_cluster')
        self.data = data
        X = data[['balance', 'age', 'gender_M']]

        try:
            fig = ff.create_dendrogram(X)
            plotly.offline.plot(fig, image_filename="dendogram.png", image='png')
            print("the dendogram saved in  html file, open it and your image will be saved as dendogram.png")

            #perform agglomerative clustering
            clusterer = AgglomerativeClustering(n_clusters=n_cluster).fit(X)#n_cluster=3
            data['hierarchical_labels'] = clusterer.labels_
            data.to_csv("Data_files/Clustering/Clustered_labelled_data_agglomerative.csv")

            self.logger.info('Dendogram is plotted and saved as html file and The data is labelled using hierarchical labels.')
            self.logger.info('Exiting agglomerative_cluster >> agglomerative_cluster')

        except Exception as e:
            self.logger.error('Exception occured in agglomerative_cluster method of the CreateClusters class. Exception message: ' + str(e.args))
            self.logger.info('Fitting the Agglomerative clustering on data to cluster has failed. Exited the agglomerative_cluster method of the CreateClusters class')
            raise Exception()


    def kMeans_clusters(self, data, number_of_clusters):
        """
                                Method Name: kMeans_clusters
                                Description: Create a new dataframe consisting of the cluster information.
                                Output: A dataframe with cluster column
                                On Failure: Raise Exception

                                Written By:Kishan
                                Version: 1.0
                                Revisions: None"""

        self.logger.info('Entering CreateClusters method >> kMeans_clusters')
        self.data=data
        try:
            self.kmeans = KMeans(n_clusters=number_of_clusters, init='k-means++', random_state=42)
            self.y_kmeans=self.kmeans.fit_predict(data) #  divide data into clusters

            self.data['Cluster']=self.y_kmeans  # create a new column in dataset for storing the cluster information

            # # saving the cluster model to the directory in .npy format
            # filename = 'Clustering_model/Save_model/cluster_model.npy'
            # pickle.dump(self.kmeans, open(filename, 'wb'))

            # saving the best model to the directory in .pkl format
            # filename = 'Clustering_model/Save_model/cluster_model_pkl.pickle'
            # pickle.dump(self.kmeans, open(filename, 'wb'))

            #save actual data csv file with cluster labels
            self.y_kmeans_series=pd.DataFrame(self.y_kmeans,columns=['Labels'])#a pandas series of clustersed result
            self.original_data_clustered = pd.concat([data,self.y_kmeans_series], axis = 1)

            #Saving this to csv file
            self.original_data_clustered.to_csv('Data_files/Clustering/Clustered_labelled_data_kMeans.csv')

            #SAving data for result comparision
            train_percent = .9
            np.random.seed(42)
            m = len(self.original_data_clustered.index)
            train_end = int(train_percent * m)
            df_data = self.original_data_clustered.iloc[:train_end]
            validate_data = self.original_data_clustered.iloc[train_end:]
            df_data.to_csv('Data_files/Validation/Train_Test_BankCust.csv')
            validate_data.to_csv('Data_files/Validation/Validate_BankCust.csv')

            self.logger.info('Clusters are created,cluster models and plots are saved.')
            self.logger.info('Exiting CreateClusters >> kMeans_clusters')
            return self.data #the dataset is clustered and returned as dataframe

        except Exception as e:
            self.logger.error('Exception occured in kMeans_clusters method of the CreateClusters class. Exception message: ' + str(e.args))
            self.logger.info('Fitting the data to clusters failed. Exited the kMeans_clusters method of the CreateClusters class')
            raise Exception()

    
