from schema import Schema, And, Use, Optional, SchemaError, Regex
import jsonschema
import re

PATTERN_ACCOUNT = r'ACC-\d{10}'
PATTERN_CURRENCY = r'\b[A-Za-z]{3}\b'
PATTERN_LONG_LAT = r'\b[0-9]{3}.[0-9]{2} -[0-9]{2}.[0-9]{2}\b'
PATTERN_MERCHANT_ID = r'\b[A-Za-z0-9]{8}-[A-Za-z0-9]{4}-[A-Za-z0-9]{4}-[A-Za-z0-9]{4}-[A-Za-z0-9]{12}\b'
PATTERN_CUSTOMER_ID = r'CUS-\d{10}'
PATTERN_EXTRACTION_DATE = r'\b[0-9]{4}-[0-9]{2}-[A-Za-z0-9]{5}:[0-9]{2}:[0-9]{2}.[0-9]{3}\+[0-9]{4}\b'

bankCustomerSchema = Schema({'_id': str,
                  'status': And(Use(str.lower), lambda s: s in ('authorized','posted')),
                  Optional('card_present_flag'): And(Use(str.lower), lambda s: s in ('0' , '1' ,'', 'null')),
                  Optional('bpay_biller_code'): And(Use(str.lower), lambda s: s in ('0' , 'land water & planning east melbourne' ,'', 'null', 'the discount chemist group')),
                  'account': Regex(PATTERN_ACCOUNT, flags=re.I),
                  'currency': Regex(PATTERN_CURRENCY, flags=re.I),
                  'long_lat': Regex(PATTERN_LONG_LAT, flags=re.I),
                  'txn_description': And(Use(str.lower), lambda s: s in ('inter bank','pay/salary','payment','phone bank','pos','sales-pos')),
                   Optional('merchant_id'): Regex(PATTERN_MERCHANT_ID, flags=re.I),
                   Optional('merchant_code'): And(Use(str.lower), lambda s: s in ('0' ,'', 'null')),
                   'first_name': str,
                   'balance': float,
                   Optional('date'): Regex(PATTERN_EXTRACTION_DATE, flags=re.I),
                   'gender': And(Use(str.lower), lambda s: s in ('f','m')),
                   'age': And(Use(int), lambda n: 18 <= n <= 78),
                   'merchant_suburb': str,
                   Optional('merchant_state'): Regex(PATTERN_CURRENCY, flags=re.I),
                   'extraction': Regex(PATTERN_EXTRACTION_DATE, flags=re.I),
                   'amount': float,
                   'transaction_id': str,
                   'country': str,
                   'customer_id': Regex(PATTERN_CUSTOMER_ID, flags=re.I),
                    Optional('merchant_long_lat'): Regex(PATTERN_LONG_LAT, flags=re.I),
                   'movement': And(Use(str.lower), lambda s: s in ('debit', 'credit'))
                 })

class SchemaStructure:
    """
    This class shall  be used for Validiation the data usinf json schema for new entry to mongoDB.

    Written By: Neha_Kushwaha
    Version: 1.0
    Revisions: None

    """
    def __init__(self, logger_object):
        self.logger = logger_object

    def validate_schema(self, data):
        """
        Method Name: validate_schema
        Description: This method validates data using json schema.
        Output: If valid data or not.
        On Failure: Raise Exception

        Written By: Neha_Kushwaha
        Version: 1.0
        Revisions: None

        """
        self.logger.info('Entering SchemaStructure >> validate_schema')
        try:
            bankCustomerSchema.validate(data)
            self.logger.info('Data Validation is Successful.')
            self.logger.info('Exiting SchemaStructure >> validate_schema')
            return bankCustomerSchema.is_valid(data)
        except Exception as e:
            self.logger.error('Exception occured in validate_schema method of the SchemaStructure class. Exception message: '+str(e.args))
            self.logger.info('Data validation failed, Check lvalidate_schema og for more info')
            raise Exception()
