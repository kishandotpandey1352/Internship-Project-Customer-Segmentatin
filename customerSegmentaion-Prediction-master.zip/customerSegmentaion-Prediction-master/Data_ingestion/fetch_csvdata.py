import pandas as pd

class DataGetterCSV:
    """
    This class shall  be used for obtaining the data from the source for training.

    Written By: Neha_Kushwaha
    Version: 1.0
    Revisions: None

    """
    def __init__(self,training_file, logger_object):
        self.training_file=training_file  #provide excel location here
        self.logger=logger_object

    def get_data(self):
        """
        Method Name: get_data
        Description: This method reads the data from source.
        Output: A pandas DataFrame.
        On Failure: Raise Exception

         Written By: iNeuron Intelligence
        Version: 1.0
        Revisions: None

        """
        self.logger.info('self.file_object,''Entered the get_data method of the DataGetterCSV class')
        try:
            self.data= pd.read_csv(self.training_file) # reading the data file
            self.logger.info('self.file_object,''Data Load Successful.Exited the get_data method of the DataGetterCSV class')
            return self.data
        except Exception as e:
            self.logger.info('self.file_object,''Exception occured in get_data method of the DataGetterCSV class. Exception message: '+str(e))
            self.logger.info('Data Load Unsuccessful.Exited the get_data method of the DataGetterCSV class')
            raise Exception()


