from pymongo import MongoClient

class InsertDataMONGODB:
    """
    This class shall  be used for obtaining the data from the source for training.

    Written By: Neha_Kushwaha
    Version: 1.0
    Revisions: None

    """
    def __init__(self,logger_object):
        self.uri="mongodb+srv://Bank_Customer_Ineuron:qwertyuiop1@cluster0.byqvv.mongodb.net/Bank_Customer_Ineuron?retryWrites=true&w=majority"
        self.database_name = 'Bank_Customer_Segmentation'
        self.logger=logger_object

    def insert_data(self, jsonfile):
        """
        Method Name: insert_data
        Description: This method reads the data from source.
        Output: A pandas DataFrame.
        On Failure: Raise Exception

        Written By: Neha_Kushwaha
        Version: 1.0
        Revisions: None

        """
        self.logger.info('Entering InsertDataMONGODB >> insert_data')
        try:
            client = MongoClient(self.uri) #connect to the client
            db = client.get_database(self.database_name) #Get Database details
            #select the collection within the database
            mongodDbCollection = db.Customer_Details
            #cinsert to mongodb
            mongodDbCollection.insert(jsonfile)
            self.logger.info('Data Inserted Successfully to mongoBD')
            self.logger.info('Exiting InsertDataMONGODB >> insert_data')
        except Exception as e:
            self.logger.error('Exception occured in insert_data method of the InsertDataMONGODB class. Exception message: '+str(e.args))
            self.logger.info('Data Insert Unsuccessful.Exited the insert_data method of the InsertDataMONGODB class')
            raise Exception()


