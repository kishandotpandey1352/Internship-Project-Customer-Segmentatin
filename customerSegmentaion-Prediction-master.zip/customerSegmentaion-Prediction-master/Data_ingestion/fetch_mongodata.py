import pandas as pd
import numpy as np
from pymongo import MongoClient
#from save_as_npy import Data_saveANpy

class DataGetterMONGODB:
    """
    This class shall  be used for obtaining the data from the source for training.

    Written By: Neha_Kushwaha
    Version: 1.0
    Revisions: None

    """
    def __init__(self, logger_object):
        self.uri="mongodb+srv://Bank_Customer_Ineuron:qwertyuiop1@cluster0.byqvv.mongodb.net/Bank_Customer_Ineuron?retryWrites=true&w=majority"
        self.database_name = 'Bank_Customer'
        self.logger=logger_object

    def get_data(self):
        """
        Method Name: get_data
        Description: This method reads the data from source.
        Output: A pandas DataFrame.
        On Failure: Raise Exception

        Written By: Neha_Kushwaha
        Version: 1.0
        Revisions: None

        """
        self.logger.info('Entering DataGetterMONGODB >> get_data')
        try:
            client = MongoClient(self.uri) #connect to the client
            db = client.get_database(self.database_name) #Get Database details
            #select the collection within the database
            mongodDbCollection = db.Customer_Details
            #convert entire collection to Pandas dataframe
            data = pd.DataFrame(list(mongodDbCollection.find()))
            #Save Data to .np extension
            #np.save('Data_Saved/mongoPdData.npy', data)
            self.logger.info('Data Load Successfully from mongoDB')
            self.logger.info('Exiting DataGetterMONGODB >> get_data')
            return data
        except Exception as e:
            self.logger.error('Exception occured in get_data method of the DataGetterMONGODB class Exception message: '+str(e))
            self.logger.info('Data Load Unsuccessful. Exited the get_data method of the DataGetterMONGODB class')
            raise Exception()


