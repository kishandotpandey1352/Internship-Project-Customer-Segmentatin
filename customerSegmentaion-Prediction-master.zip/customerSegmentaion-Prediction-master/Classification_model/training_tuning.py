from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV, cross_val_score
from xgboost import XGBClassifier
from sklearn import metrics
import xgboost
import pickle
import numpy as np
import pandas as pd
import optuna
from optuna.pruners import MedianPruner
from optuna import trial, visualization
from optuna.samplers import TPESampler
import timeit
import sys
from sklearn.pipeline import Pipeline
from optuna.integration.mlflow import MLflowCallback
from sklearn.metrics import confusion_matrix, classification_report, auc, roc_auc_score, \
                            precision_recall_curve, roc_curve, accuracy_score, f1_score


class ModelFinder:
    """
                This class shall  be used to find the model with best accuracy and AUC score.
                Written By:  Bharat
                Version: 1.0
                Revisions: None

                """

    def __init__(self, logger_object, x_train, y_train, x_test, y_test):
        self.logger = logger_object
        # self.clf = RandomForestClassifier()
        # self.xgb = XGBClassifier(objective='binary:logistic')
        self.train_x = x_train
        self.train_y = y_train
        self.test_x = x_test
        self.test_y = y_test

    def random_forest(self, params):
        """
                                Method Name: random_forest
                                Description: get the parameters for Random Forest Algorithm which give the best accuracy.
                                             Use Hyper Parameter Tuning.
                                Output: The model with the best parameters
                                On Failure: Raise Exception

                                Written By: Bharat
                                Version: 1.0
                                Revisions: None

                        """
        self.logger.info(
            'Entered the random_forest method of the Model_Finder class')
        try:
            #creating a new model with the best parameters
            self.clf = RandomForestClassifier(**params)
            # training the mew model
            self.clf.fit(self.train_x, self.train_y)
            # self.logger.info('Random Forest best params: '+str(self.grid.best_params_)+'. Exited the'
            #                  'get_best_params_for_random_forest method of the Model_Finder class')

            return self.clf
        except Exception as e:
            self.logger.info('Exception occurred in random_forest method of the'
                             ' Model_Finder class. Exception message:  ' + str(e))
            self.logger.info('Random Forest Parameter tuning failed. Exited the random_forest '
                             'method of the Model_Finder class')
            raise Exception()

    def xg_boost(self, params):
        """
                                    Method Name: xg_boost
                                    Description: get the parameters for XGBoost Algorithm which give the best accuracy.
                                                     Use Hyper Parameter Tuning.
                                    Output: The model with the best parameters
                                    On Failure: Raise Exception

                                    Written By: Bharat
                                    Version: 1.0
                                    Revisions: None

                                """
        self.logger.info(
            'Entered the xg_boost method of the Model_Finder class')
        try:
            # creating a new model with the best parameters
            self.xgb = XGBClassifier(**params)
            # training the mew model
            self.xgb.fit(self.train_x, self.train_y)
            return self.xgb
        except Exception as e:
            self.logger.info('Exception occurred in xg_boost method of the Model_Finder class.'
                             ' Exception message:  ' + str(e))
            self.logger.info('XGBoost Parameter tuning  failed. Exited the xg_boost method of the '
                             'Model_Finder class')
            raise Exception()
    
    def objective_RF(self, trial, train_x, train_y):
        self.logger.info(
            'Entered the objective_RF method of the Model_Finder class')
        try:
            # parameters to optimize
            n_estimators = trial.suggest_int('n_estimators', 10, 1000)
            max_depth = trial.suggest_int('max_depth', 2, 32, log=True)
            
            self.logger.info('n_estimators: '+str(n_estimators))
            self.logger.info('max_depth: '+str(max_depth))
            
            # our ML pipeline
            clf = RandomForestClassifier(n_estimators=n_estimators,
                                        max_depth=max_depth,
                                        random_state=25
                                        )
            
            # return average 5-fold CV
            self.logger.info('CV Score for trial : ' + str(cross_val_score(clf, self.train_x, self.train_y, n_jobs=-1, cv=5).mean()))
            return cross_val_score(clf, self.train_x, self.train_y, n_jobs=-1, cv=5).mean()
        except Exception as e:
            self.logger.info('Exception occurred in objective_RF method of the Model_Finder class.'
                             ' Exception message:  ' + str(e))
            self.logger.info('objective_RF Parameter tuning  failed. Exited the objective_RF method of the '
                             'Model_Finder class')
            raise Exception()

    def objective_XG(self, trial, train_x, train_y):
        self.logger.info(
            'Entered the objective_XG method of the Model_Finder class')
        try:
            # parameters to optimize
            max_depth = trial.suggest_int('max_depth', 2, 32, log=True)
            n_estimators = trial.suggest_int('n_estimators', 10, 200)
            learning_rate = trial.suggest_uniform('learning_rate', 0, 0.1)
            
            self.logger.info('n_estimators: '+str(n_estimators))
            self.logger.info('max_depth: '+str(max_depth))
            self.logger.info('learning_rate: '+str(learning_rate))
            
            # our ML pipeline
            clf = XGBClassifier(n_estimators=n_estimators,
                                        max_depth=max_depth,
                                        learning_rate = learning_rate,
                                        random_state=25
                                        )
            
            # return average 5-fold CV
            self.logger.info('CV Score for trial : ' + str(cross_val_score(clf, self.train_x, self.train_y, n_jobs=-1, cv=5).mean()))
            return cross_val_score(clf, self.train_x, self.train_y, n_jobs=-1, cv=5).mean()
        except Exception as e:
            self.logger.info('Exception occurred in objective_XG method of the Model_Finder class.'
                             ' Exception message:  ' + str(e))
            self.logger.info('objective_XG Parameter tuning  failed. Exited the objective_RF method of the '
                             'Model_Finder class')
            raise Exception()


    def get_best_model(self, validate_features, validate_label):
        """
                                                Method Name: get_best_model
                                                Description: Find out the Model which has the best AUC score.
                                                Output: The best model name and the model object
                                                On Failure: Raise Exception

                                                Written By: Bharat
                                                Version: 1.0
                                                Revisions: None

                                        """
        self.logger.info(
            'Entered the get_best_model method of the Model_Finder class')
        # create best model for XGBoost
        try:

            model_finder = ModelFinder(
                self.logger, self.train_x, self.train_y, self.test_x, self.test_y)

            # create best model for XgBoost
            self.logger.info('-------------------------XgBoost-------------------------')
           
            mlflow_cb = MLflowCallback(
                tracking_uri='mlruns', metric_name='ROC AUC')
            study_xgboost = optuna.create_study(study_name='customer_classification_prediction',
                                                     direction='maximize',
                                                     pruner=optuna.pruners.HyperbandPruner(max_resource="auto"))
            study_xgboost.optimize(
                lambda trial: model_finder.objective_XG(trial, train_x= self.train_x, train_y= self.train_y), n_trials=20, callbacks=[mlflow_cb])


            self.logger.info('Best trial: score {},\nparams {}'.format(
                study_xgboost.best_trial.value, study_xgboost.best_trial.params))
            # params = model_finder.stepwise_optimization()
            self.xgboost = model_finder.xg_boost(
                study_xgboost.best_trial.params)
            self.prediction_xgboost = self.xgboost.predict_proba(
                self.test_x)  # Predictions using the XGBoost Model
            
            # if there is only one label in y, then roc_auc_score returns error. We will use accuracy in that case
            if len(self.test_y.unique()) == 1:
                self.logger.info('Test data')
                self.xgboost_score = accuracy_score(
                    self.test_y, self.prediction_xgboost)
                self.logger.info('Accuracy for XGBoost test data:' +
                                 str(self.xgboost_score))  # Log AUC
            else:
                self.logger.info('Test data')
                self.xgboost_auc = roc_auc_score(
                    self.test_y, self.prediction_xgboost, multi_class="ovr")
                self.logger.info('AUC for XGBoost test data:' +
                                 str(self.xgboost_auc))  # Log ROC
            
            y_pred = self.xgboost.predict(self.test_x)
            self.logger.info(classification_report(y_true= self.test_y, y_pred=y_pred))
            self.logger.info(confusion_matrix(y_true= self.test_y, y_pred=y_pred))

            # create best model for Random Forest
            self.logger.info('-------------------------RandomForest-------------------------')

            mlflow_cb = MLflowCallback(
                tracking_uri='mlruns', metric_name='ROC AUC')
            study_randomForest = optuna.create_study(study_name='customer_classification_prediction',
                                                     direction='maximize',
                                                     pruner=optuna.pruners.HyperbandPruner(max_resource="auto"))
            study_randomForest.optimize(
                lambda trial: model_finder.objective_RF(trial, train_x= self.train_x, train_y= self.train_y), n_trials=20, callbacks=[mlflow_cb])

            self.logger.info('Best trial: score {},\nparams {}'.format(
                study_randomForest.best_trial.value, study_randomForest.best_trial.params))
            self.random_forest = model_finder.random_Forest(
                study_randomForest.best_trial.params)
            self.prediction_random_forest = self.random_forest.predict_proba(
                self.test_x)  # prediction using the Random Forest Algorithm

            # if there is only one label in y, then roc_auc_score returns error. We will use accuracy in that case
            if len(self.test_y.unique()) == 1:
                self.logger.info('Test data')
                self.random_forest_score = accuracy_score(
                    self.test_y, self.prediction_random_forest)
                self.logger.info('Accuracy for RF test data:' +
                                 str(self.random_forest_score))
            else:
                self.logger.info('Test data')
                self.random_forest_auc = roc_auc_score(
                    self.test_y, self.prediction_random_forest, multi_class="ovr")
                self.logger.info('AUC for RF test data:' +
                                 str(self.random_forest_auc))

            y_pred = self.random_forest.predict(self.test_x)
            self.logger.info(classification_report(y_true= self.test_y, y_pred=y_pred))
            self.logger.info(confusion_matrix(y_true= self.test_y, y_pred=y_pred))

            #comparing the two models
            if(self.random_forest_auc < self.xgboost_auc):
                with open('Model/customer_classifier_model.sav',
                          'wb') as f:
                    pickle.dump(self.xgboost, f)
                return 'XGBoost', self.xgboost
            else:
                with open('Model/customer_classifier_model.sav',
                          'wb') as f:
                    pickle.dump(self.random_forest, f)
                return 'RandomForest', self.random_forest

        except Exception as e:
            self.logger.info('Exception occured in get_best_model method of the Model_Finder class.'
                             'Exception message:  ' + str(e))
            self.logger.info(
                'Model Selection Failed. Exited the get_best_model method of the Model_Finder class')
            raise Exception()

    # def report(self, clf, display_scores=[], sample_weight=None, refit=False, importance_plot=False, confusion_labels=['class 0', 'class 1', 'class 2'], feature_labels=None, verbose=True):
    #     """ Trains the passed classifier if not already trained and reports
    #         various metrics of the trained classifier """
    #     dump = dict()

    #     y_pred_train = clf.predict(self.train_x)
    #     train_acc = accuracy_score(self.train_y, y_pred_train)

    #     ## Testing
    #     start = timeit.default_timer()
    #     test_predictions = clf.predict(self.test_x)
    #     end = timeit.default_timer()
    #     test_time = end - start

    #     test_acc = accuracy_score(self.test_y, test_predictions)
    #     y_probs = clf.predict_proba(self.test_x)
    #     roc_auc = roc_auc_score(self.test_y, y_probs,multi_class="ovr")

    #     ## Additional scores
    #     scores_dict = dict()
    #     for func in display_scores:
    #         scores_dict[func.__name__] = [
    #             func(self.train_y, y_pred_train), func(self.test_y, test_predictions)]

    #      ## Model Memory
    #     model_mem = round(sys.getsizeof(pickle.dumps(clf)) / 1024, 2)

    #     print(clf)
    #     print("\n=============================> TRAIN-TEST DETAILS <======================================")

    #     ## Metrics
    #     print(f"Train Size: {self.train_x.shape[0]} samples")
    #     print(f"Test Size: {self.test_y.shape[0]} samples")
    #     print("---------------------------------------------")
    #     # print(f"Training Time: {round(train_time, 3)} seconds")
    #     # print(f" Testing Time: {round(test_time, 3)} seconds")
    #     # print("---------------------------------------------")
    #     print("Train Accuracy: ", train_acc)
    #     print(" Test Accuracy: ", test_acc)
    #     print("---------------------------------------------")

    #     if display_scores:
    #         for k, v in scores_dict.items():
    #             score_name = ' '.join(map(lambda x: x.title(), k.split('_')))
    #             print(f'Train {score_name}: ', v[0])
    #             print(f' Test {score_name}: ', v[1])
    #             print()
    #             print("---------------------------------------------")

    #     print(" Area Under ROC (test): ", roc_auc)
    #     print("---------------------------------------------")
    #     print(f"Model Memory Size: {model_mem} kB")
    #     print("\n=============================> CLASSIFICATION REPORT <===================================")

    #     ## Classification Report
    #     clf_rep = classification_report(self.test_y, test_predictions, output_dict=True)

    #     print(classification_report(self.test_y, test_predictions, target_names=confusion_labels))

    #     # if verbose:
    #     #     print(
    #     #         "\n================================> CONFUSION MATRIX <=====================================")

    #     #     ## Confusion Matrix HeatMap
    #     #     display(confusion_plot(confusion_matrix(
    #     #         y_test, test_predictions), labels=confusion_labels))
    #     #     print(
    #     #         "\n=======================================> PLOTS <=========================================")

    #     #     ## Variable importance plot
    #     #     fig, axes = plt.subplots(nrows=2, ncols=2, figsize=(14, 10))
    #     #     roc_axes = axes[0, 0]
    #     #     pr_axes = axes[0, 1]
    #     #     importances = None

    #     #     if importance_plot:
    #     #         if not feature_labels:
    #     #             raise RuntimeError("'feature_labels' argument not passed "
    #     #                                "when 'importance_plot' is True")
    #     #         try:
    #     #             importances = pd.Series(clf.feature_importances_,
    #     #                                     index=feature_labels).sort_values(ascending=False)
    #     #         except AttributeError:
    #     #             try:
    #     #                 importances = pd.Series(clf.coef_.ravel(), index=feature_labels) \
    #     #                     .sort_values(ascending=False)
    #     #             except AttributeError:
    #     #                 pass

    #     #     if importances is not None:
    #     #         # Modifying grid
    #     #         grid_spec = axes[0, 0].get_gridspec()
    #     #         for ax in axes[:, 0]:
    #     #             ax.remove()   # remove first column axes
    #     #             large_axs = fig.add_subplot(grid_spec[0:, 0])

    #     #             # Plot importance curve
    #     #             feature_importance_plot(importances=importances.values,
    #     #                                     feature_labels=importances.index,
    #     #                                     ax=large_axs)
    #     #             large_axs.axvline(x=0)

    #     #             # Axis for ROC and PR curve
    #     #             roc_axes = axes[0, 1]
    #     #             pr_axes = axes[1, 1]
    #     #     else:
    #     #         # remove second row axes
    #     #         for ax in axes[1, :]:
    #     #             ax.remove()
    #     # else:
    #     #     # remove second row axes
    #     #     for ax in axes[1, :]:
    #     #         ax.remove()

    #     #     ## ROC and Precision-Recall curves
    #     #     clf_name = clf.__class__.__name__
    #     #     roc_plot(y_test, y_probs, clf_name, ax=roc_axes)
    #     #     precision_recall_plot(y_test, y_probs, clf_name, ax=pr_axes)

    #     #     fig.subplots_adjust(wspace=5)
    #     #     fig.tight_layout()
    #     #     display(fig)

    #     ## Dump to report_dict
    #     dump = dict(clf=clf, accuracy=[train_acc, test_acc], **scores_dict,
    #                 test_time=test_time, test_predictions=test_predictions,
    #                 test_probs=y_probs, report=clf_rep, roc_auc=roc_auc,
    #                 model_memory=model_mem)

    #     return clf, dump
