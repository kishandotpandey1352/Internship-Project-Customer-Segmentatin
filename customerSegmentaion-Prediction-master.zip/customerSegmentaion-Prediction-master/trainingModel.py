from Data_ingestion.fetch_mongodata import DataGetterMONGODB
from Data_ingestion.insert_to_mongojson import InsertDataMONGODB
from Data_preprocessing.preprocessing import Preprocessor
import pdpipe as pdp
import numpy as np
import pandas as pd
import json
import bson
import pickle
from Capture_logs import get_logger
from Clustering_model.clustering import CreateClusters
from sklearn.model_selection import train_test_split
from Classification_model import training_tuning
from sklearn.metrics import classification_report


class trainModel:
    def __init__(self):
        logger_class = get_logger.LoggerClass()
        self.logger = logger_class.get_logger('Logs/main.log')

    def trainingModel(self):
        self.logger.info('Entering trainModel >> trainingModel')
        try:
            ###########-----------------------Fetch the Data----------------------------############
            # Getting the data from the source
            data_getter=DataGetterMONGODB(self.logger)
            data = data_getter.get_data()

            ###########-----------------------EDA STARTS----------------------------############
            #The data preprocessing for clustering and classification"""
            preProcessor=Preprocessor(self.logger)
            col_to_remove_df = pd.read_csv('Data_files/Config/remove_features.csv')
           
            pipeline = pdp.ColDrop(columns=col_to_remove_df['Column_list'].to_list())
            # check if missing values are present in the dataset
            is_null_present=preProcessor.is_null_present(data)
            # if missing values are there, replace them appropriately.
            if(is_null_present):
                pipeline += pdp.RegexReplace('card_present_flag',"Null","1")

             # One hot encoding
            onehotlist = pd.read_csv('Data_files/Config/Categorical_features.csv')
            pipeline += pdp.OneHotEncode(columns=onehotlist['Column_list'].to_list(), drop=True)
            
             # correlation
            threshold = 0.85
            corr_features = preProcessor.correlation(data, threshold)
            pipeline += pdp.ColDrop(columns=list(corr_features))

            #Outliers
            outliers = pd.read_csv('Data_files/Config/outlier_features.csv')
            outliers_columns = outliers['Column_list'].to_list()
            for column_name in outliers_columns:
                data = preProcessor.check_Outliers(data, column_name)

            # start : Used at time of classification
            data_scale = data
            data_scale = pipeline(data_scale)
            data_scale = data_scale[['balance', 'age', 'gender_M']]
            pipeline_scale = pdp.Scale("StandardScaler")
            data_scale = pipeline_scale(data_scale)
            with open('Model/customer_classifier_scalar.sav',
                          'wb') as f:
                    pickle.dump(pipeline_scale, f)
            # end : Used at time of classification

            # Standarized the data
            pipeline += pdp.Scale("StandardScaler")
            
            #Getting final processed data from pipeline
            data = pipeline(data)
            data.to_csv('Data_files/EDA/Pre_processed_data.csv') # storing the null column information to file

            ###########----------------------------EDA ENDS--------------------------------############
         
            ###########-----------------------CLUSTERING STARTS----------------------------############

            #get the data for elbow plot
            # data = pd.read_csv("Data_preprocessing/EDA_BankCust.csv")
            cluster_obj = CreateClusters(self.logger)  # class object intialized
            number_of_cluster=cluster_obj.elbow_plot(data)#checking method elbow_plot()
            self.logger.info("the number of clusters from K-means clustering is :{}".format(number_of_cluster))

            #use silhouette plot
            cluster_obj.silhouet_plot(data)

            # Create Dendogram using Aglomerative clustering
            cluster_obj.agglomerative_cluster(data, number_of_cluster)

            #Create clusters and do labelling of data and save it in a csv format
            number_of_cluster = 3
            clustered_data = cluster_obj.kMeans_clusters(data, number_of_cluster)
            ###########-----------------------CLUSTERING ENDS----------------------------############

            ###########---------------------CLASSIFICATION STARTS------------------------############
            # Prepare the feature and Label columns
            # preProcessor=Preprocessor(self.logger)
            # clustered_data = pd.read_csv('Data_files/Clustering/Clustered_labelled_data_kMeans.csv')
            df_data,validate_data =  preProcessor.train_validate_test_split(clustered_data)
            
            cluster_features = df_data[['balance', 'age', 'gender_M']]
            cluster_label = df_data['Cluster']

            #unseen data
            validate_features = validate_data[['balance', 'age', 'gender_M']]
            validate_label = validate_data['Cluster']

            # splitting the data into training and test set for each cluster one by one
            x_train, x_test, y_train, y_test = train_test_split(cluster_features, cluster_label, test_size=1 / 3,
                                                                random_state=355)
            model_finder = training_tuning.ModelFinder(self.logger, x_train, y_train, x_test, y_test)  # object initialization

            # getting the best model for each of the clusters
            best_model_name, best_model = model_finder.get_best_model(validate_features,validate_label)

            self.logger.info(f'best_model_name : {best_model_name}')
            self.logger.info(f'best_model : {best_model}')

            ###########---------------------CLASSIFICATION ENDS--------------------------############

            # logging the successful Training
            self.logger.info('Successful End of Training')
            self.logger.info('Exiting trainModel >> trainingModel')
            return "training completed"
        except Exception:
            # logging the unsuccessful Training
            self.logger.info('Unsuccessful End of trainModel >> trainingModel')
            self.logger.error("Exception occurred in trainModel >> trainingModel", exc_info=True)
            raise Exception