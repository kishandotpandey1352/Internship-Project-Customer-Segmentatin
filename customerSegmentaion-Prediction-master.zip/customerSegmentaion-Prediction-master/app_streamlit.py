# # -*- coding: utf-8 -*-
# """
# Created on Sat Oct 03 02:20:31 2020

# @author: Neha Kushwaha
# """

import numpy as np
import pickle
import pandas as pd
import streamlit as st 
import warnings
from Capture_logs import get_logger

sav_file = "Model/customer_classifier_model.sav"
with warnings.catch_warnings():
      warnings.simplefilter("ignore", category=UserWarning)
      classifier = pickle.load(open(sav_file, 'rb'))
      # load the scaler
      scaler_std = pickle.load(open('Model/customer_classifier_scalar.sav', 'rb'))

#@app.route('/predict',methods=["Get"])
def customer_classification(Balance,Age,Gender,logger):
  logger.info("Entering app >> customer_classification method")
  try:
    if Gender == 'Male' :
      Gender_temp = 1
    else:
      Gender_temp = 0 
    array_std = list()
    array_std.append(Balance)
    array_std.append(Age)
    array_std.append(Gender_temp)
    logger.info(array_std)
    df = pd.DataFrame([array_std])
    df.columns =['balance', 'age', 'gender_M']
    logger.info(df)
    array_std_scl = scaler_std(df)
    logger.info(array_std_scl)
    prediction=classifier.predict(array_std_scl)
    logger.info(prediction)
    return prediction
  except Exception:
    # logging the unsuccessful Training
    logger.info('Unsuccessful End app >> customer_classification method')
    logger.error("Exception occurred in app >> customer_classification", exc_info=True)
    raise Exception


def main():
    logger_class = get_logger.LoggerClass()
    logger = logger_class.get_logger('Logs/streamlit.log')
    logger.info("Entering app >> main method")
    st.title("Bank Customer Classifier")
    html_temp = """
    <div style="background-color:tomato;padding:10px">
    <h2 style="color:white;text-align:center;">ABC Bank Product Recommendation System</h2>
    </div>
    """
    
    try:
      st.markdown(html_temp,unsafe_allow_html=True)
      Gender = st.selectbox('Gender of the Customer ',('Male', 'Female'))
      Age = st.slider('Age of the Customer', min_value=18, max_value=78, step=1)
      Balance = st.number_input("The balance amount of customer account", min_value = 0.0000)
    
      result=""
      if st.button("Customer Classifier"):
          result=customer_classification(Balance,Age,Gender,logger)
          if str(result) == '[0]':
            result = "Class 0"
          if str(result) == '[1]':
              result = "Class 1"
          if str(result) == '[2]':
              result = "Class 2"
      st.success('The customer belongs to : {}'.format(result))
      if st.button("About"):
          st.text("Bank Customer Classifier")
          st.text("Built with Streamlit")
    except ValueError:
      print('Please enter input in correct format')
    except Exception:
            # logging the unsuccessful Training
            logger.info('Unsuccessful End app >> main method')
            logger.error("Exception occurred in app >> main", exc_info=True)
            raise Exception

    
    

if __name__=='__main__':
    main()
    
    
    